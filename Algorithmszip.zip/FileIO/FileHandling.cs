﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileIO
{
    public class FileHandling

    {
        public string[] fileReader(string filePath)
        {
            string[] list = {};


            return list;

        }
    }
}
